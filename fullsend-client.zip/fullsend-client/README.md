# FullSend Client (Meteor addon, Minecraft 26.2)

Modul **Sound ESP** v kategorii **FullSend**:
- zachyti vsechny zvuky ve svete,
- v nastaveni modulu (GUI) je seznam vsech slysenych zvuku s vyhledavanim a checkboxy,
- vybrane zvuky se ve svete vykresli jako boxy,
- hodne `entity.villager.*` zvuku v jedne oblasti = zelena **Trader farm** + hlaska do chatu.

## Instalace
Do `mods/`: Fabric Loader 0.19.3+, Fabric API pro 26.2, Meteor Client 26.2, a tenhle addon (`fullsend-client-1.0.0.jar`). Potrebujes Java 25.

## Sestaveni jaru
**A) Bez instalace (GitHub Actions):** nahraj slozku do noveho GitHub repa -> zalozka Actions -> "Build FullSend Client" -> stahni artefakt `fullsend-client`.

**B) Lokalne:** JDK 25 + Gradle 9.6.1, ve slozce `gradle build`; jar je v `build/libs/`.
(Wrapper: `gradle wrapper --gradle-version 9.6.1`, potom `./gradlew build`.)
