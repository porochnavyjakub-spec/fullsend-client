package fullsend.modules;

import fullsend.FullSendAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.PlaySoundEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.resources.sounds.SoundInstance;

import java.util.*;

/**
 * FullSend Sound ESP.
 * Zachyti vsechny zvuky, v GUI modulu si zaskrtnes ktere chces sledovat,
 * a ve svete se u nich vykresli box. Hodne villager zvuku na jednom miste = trading farma.
 */
public class SoundEsp extends Module {

    // ---------- nastaveni ----------
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgFarm = settings.createGroup("Farmy");
    private final SettingGroup sgRender = settings.createGroup("Vzhled");

    private final Setting<List<String>> selectedSetting = sgGeneral.add(new StringListSetting.Builder()
        .name("vybrane-zvuky")
        .description("Zvuky, ktere se sledujou (spravuje se zaskrtavanim nize).")
        .defaultValue(new ArrayList<>())
        .build());

    private final Setting<Integer> maxAge = sgGeneral.add(new IntSetting.Builder()
        .name("zivotnost-s")
        .description("Jak dlouho se zvuk zobrazuje (sekundy).")
        .defaultValue(20).min(1).sliderMax(120).build());

    private final Setting<Double> maxDistance = sgGeneral.add(new DoubleSetting.Builder()
        .name("max-vzdalenost")
        .description("Dal nez tohle se zvuky nezobrazujou.")
        .defaultValue(128).min(8).sliderMax(512).build());

    private final Setting<Boolean> ignoreSelf = sgGeneral.add(new BoolSetting.Builder()
        .name("ignorovat-sebe")
        .description("Ignoruje zvuky ve vzdalenosti < 1.5 bloku od tebe.")
        .defaultValue(true).build());

    private final Setting<Boolean> chat = sgGeneral.add(new BoolSetting.Builder()
        .name("chat")
        .description("Vypisuje nove zachycene zvuky do chatu.")
        .defaultValue(false).build());

    private final Setting<Boolean> farmDetect = sgFarm.add(new BoolSetting.Builder()
        .name("detekce-farem")
        .description("Hodne villager zvuku na jednom miste = trading farma.")
        .defaultValue(true).build());

    private final Setting<Integer> farmMinSounds = sgFarm.add(new IntSetting.Builder()
        .name("min-zvuku")
        .description("Kolik villager zvuku v okoli = farma.")
        .defaultValue(12).min(3).sliderMax(60).build());

    private final Setting<Integer> clusterSize = sgFarm.add(new IntSetting.Builder()
        .name("velikost-bunky")
        .description("Velikost oblasti pro seskupovani (bloky).")
        .defaultValue(16).min(4).sliderMax(64).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("vypln").defaultValue(new SettingColor(91, 140, 255, 40)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("okraj").defaultValue(new SettingColor(91, 140, 255, 255)).build());

    private final Setting<SettingColor> farmColor = sgRender.add(new ColorSetting.Builder()
        .name("barva-farmy").defaultValue(new SettingColor(91, 255, 160, 255)).build());

    // ---------- data ----------
    private static class Entry {
        final String id; int count; long lastSeen; double x, y, z;
        Entry(String id) { this.id = id; }
    }
    private static class Hit {
        final String id; final double x, y, z; final long time;
        Hit(String id, double x, double y, double z, long time) {
            this.id = id; this.x = x; this.y = y; this.z = z; this.time = time;
        }
    }
    private static class Target {
        final String label; final double x, y, z; final int count; final boolean farm;
        Target(String label, double x, double y, double z, int count, boolean farm) {
            this.label = label; this.x = x; this.y = y; this.z = z; this.count = count; this.farm = farm;
        }
    }

    private final Map<String, Entry> log = new HashMap<>();
    private final List<Hit> hits = new ArrayList<>();
    private final List<Target> targets = new ArrayList<>();
    private final Set<Long> announcedFarms = new HashSet<>();
    private String searchText = "";

    public SoundEsp() {
        super(FullSendAddon.CATEGORY, "sound-esp",
            "Zachyti vsechny zvuky a ukaze ty, ktere si vyberes (villageri, hraci, trading farmy).");
    }

    @Override
    public void onDeactivate() {
        hits.clear();
        targets.clear();
        announcedFarms.clear();
    }

    // ---------- zachytavani zvuku ----------
    @EventHandler
    private void onPlaySound(PlaySoundEvent event) {
        if (mc.player == null) return;
        SoundInstance s = event.sound;

        String id = s.getIdentifier().toString().replace("minecraft:", "");
        double x = s.getX(), y = s.getY(), z = s.getZ();

        if (ignoreSelf.get() && mc.player.distanceToSqr(x, y, z) < 2.25) return;

        long now = System.currentTimeMillis();
        Entry e = log.computeIfAbsent(id, Entry::new);
        e.count++; e.lastSeen = now; e.x = x; e.y = y; e.z = z;

        if (selectedSetting.get().contains(id)) {
            hits.add(new Hit(id, x, y, z, now));
            if (chat.get()) info("%s  (%d, %d, %d)", id, (int) x, (int) y, (int) z);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        long ageMs = maxAge.get() * 1000L;
        double maxD2 = maxDistance.get() * maxDistance.get();

        hits.removeIf(h -> now - h.time > ageMs);
        targets.clear();

        double cs = clusterSize.get();
        Map<Long, List<Hit>> grid = new HashMap<>();
        for (Hit h : hits) {
            if (mc.player.distanceToSqr(h.x, h.y, h.z) > maxD2) continue;
            long gx = (long) Math.floor(h.x / cs), gz = (long) Math.floor(h.z / cs);
            grid.computeIfAbsent((gx << 32) ^ (gz & 0xFFFFFFFFL), k -> new ArrayList<>()).add(h);
        }

        for (Map.Entry<Long, List<Hit>> cell : grid.entrySet()) {
            List<Hit> c = cell.getValue();
            double sx = 0, sy = 0, sz = 0; int villagers = 0;
            Map<String, Integer> byId = new HashMap<>();
            for (Hit h : c) {
                sx += h.x; sy += h.y; sz += h.z;
                byId.merge(h.id, 1, Integer::sum);
                if (h.id.startsWith("entity.villager.")) villagers++;
            }
            int n = c.size();
            boolean farm = farmDetect.get() && villagers >= farmMinSounds.get();
            String top = Collections.max(byId.entrySet(), Map.Entry.comparingByValue()).getKey();
            targets.add(new Target(farm ? "Trader farm" : top, sx / n, sy / n, sz / n, n, farm));

            if (farm && announcedFarms.add(cell.getKey())) {
                info("Trading farma nalezena: (%d, %d, %d)", (int) (sx / n), (int) (sy / n), (int) (sz / n));
            }
        }
    }

    // ---------- vykreslovani ----------
    @EventHandler
    private void onRender3D(Render3DEvent event) {
        for (Target t : targets) {
            double r = t.farm ? 1.0 : 0.35;
            event.renderer.box(t.x - r, t.y - r, t.z - r, t.x + r, t.y + r, t.z + r,
                sideColor.get(), t.farm ? farmColor.get() : lineColor.get(), ShapeMode.Both, 0);
        }
    }

    // ---------- GUI: seznam vsech zachycenych zvuku ----------
    @Override
    public WWidget getWidget(GuiTheme theme) {
        WVerticalList root = theme.verticalList();

        WHorizontalList bar = root.add(theme.horizontalList()).expandX().widget();
        WTextBox search = bar.add(theme.textBox(searchText)).expandX().minWidth(220).widget();
        WButton refresh = bar.add(theme.button("Obnovit")).widget();
        WButton unselect = bar.add(theme.button("Zrusit vyber")).widget();
        WButton clear = bar.add(theme.button("Smazat log")).widget();

        root.add(theme.label("Zapni modul a pohybuj se po svete - zvuky se tu objevi. Zaskrtni ty, co chces sledovat."));

        WTable table = root.add(theme.table()).expandX().widget();

        Runnable fill = () -> {
            table.clear();
            String f = searchText.toLowerCase(Locale.ROOT);
            List<Entry> list = new ArrayList<>();
            for (Entry e : log.values()) if (e.id.contains(f)) list.add(e);
            list.sort((a, b) -> Long.compare(b.lastSeen, a.lastSeen));

            // vybrane (i ty co jsme zrovna neslyseli) nahore
            for (String sel : selectedSetting.get()) {
                if (log.containsKey(sel) || !sel.contains(f)) continue;
                Entry e = new Entry(sel);
                list.add(0, e);
            }

            int shown = 0;
            for (Entry e : list) {
                if (shown++ >= 250) break;
                WCheckbox cb = table.add(theme.checkbox(selectedSetting.get().contains(e.id))).widget();
                cb.action = () -> setSelected(e.id, cb.checked);
                table.add(theme.label(e.id)).expandCellX();
                table.add(theme.label("x" + e.count));
                table.row();
            }
            if (list.isEmpty()) table.add(theme.label("Zatim zadne zvuky."));
        };

        search.action = () -> { searchText = search.get(); fill.run(); };
        refresh.action = fill;
        unselect.action = () -> { selectedSetting.set(new ArrayList<>()); hits.clear(); fill.run(); };
        clear.action = () -> { log.clear(); hits.clear(); fill.run(); };

        fill.run();
        return root;
    }

    private void setSelected(String id, boolean on) {
        List<String> list = new ArrayList<>(selectedSetting.get());
        if (on) { if (!list.contains(id)) list.add(id); }
        else { list.remove(id); hits.removeIf(h -> h.id.equals(id)); }
        selectedSetting.set(list);
    }
}
